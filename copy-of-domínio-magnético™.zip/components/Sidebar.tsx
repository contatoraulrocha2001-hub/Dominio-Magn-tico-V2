
import React from 'react';
import { 
  Library, 
  ShieldAlert, 
  User as UserIcon, 
  LogOut,
  ChevronRight
} from 'lucide-react';
import { ViewMode } from '../types';

interface SidebarProps {
  currentView: ViewMode;
  setView: (view: ViewMode) => void;
  userRole: 'admin' | 'user';
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, userRole, onLogout }) => {
  const menuItems = [
    { id: ViewMode.LIBRARY, label: 'BIBLIOTECA', icon: Library },
    ...(userRole === 'admin' ? [{ id: ViewMode.ADMIN, label: 'ARSENAL', icon: ShieldAlert }] : []),
    { id: ViewMode.PROFILE, label: 'PERFIL', icon: UserIcon },
  ];

  return (
    <aside className="w-72 bg-sidebar border-r border-white/5 flex flex-col h-full z-50">
      <div className="p-8 pb-12">
        <h2 className="font-playfair text-2xl font-bold tracking-tighter">
          DOMÍNIO<br />
          <span className="text-gold italic">MAGNÉTICO</span>
          <span className="text-[10px] align-top">TM</span>
        </h2>
      </div>

      <nav className="flex-1 px-4">
        <ul className="space-y-4">
          {menuItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => setView(item.id)}
                className={`w-full group flex items-center justify-between px-4 py-4 rounded transition-all duration-300 ${
                  currentView === item.id 
                    ? 'bg-gold/10 text-gold' 
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center space-x-4">
                  <item.icon size={18} strokeWidth={1.5} />
                  <span className="text-xs font-montserrat font-bold tracking-[0.2em] pt-1">
                    {item.label}
                  </span>
                </div>
                {currentView === item.id && (
                  <ChevronRight size={14} className="animate-pulse" />
                )}
              </button>
            </li>
          ))}
        </ul>
      </nav>

      <div className="p-8 border-t border-white/5">
        <button 
          onClick={onLogout}
          className="flex items-center space-x-3 text-gray-500 hover:text-wine transition-colors group w-full"
        >
          <LogOut size={16} />
          <span className="text-[10px] font-bold tracking-widest uppercase">Encerrar Sessão</span>
        </button>
      </div>
    </aside>
  );
};
