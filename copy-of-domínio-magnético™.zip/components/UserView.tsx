
import React from 'react';
import { Resource, User } from '../types';
import { ResourceCard } from './ResourceCard';

interface UserViewProps {
  resources: Resource[];
  user: User;
}

export const UserView: React.FC<UserViewProps> = ({ resources, user }) => {
  return (
    <div className="space-y-16">
      <header>
        <h3 className="font-playfair text-white/40 text-sm tracking-widest uppercase mb-2">Coleção Exclusiva</h3>
        <h2 className="font-playfair text-6xl font-bold leading-tight">
          Sua Biblioteca de <br />
          <span className="italic text-gold">Elite Magnética</span>
        </h2>
      </header>

      {resources.length === 0 ? (
        <div className="py-32 text-center border border-white/5 bg-sidebar/30 rounded-2xl">
          <p className="font-playfair text-2xl text-gray-600 italic">O arsenal ainda está sendo abastecido.</p>
          <p className="text-xs text-gray-700 font-bold tracking-widest uppercase mt-4">Aguarde novas curadorias</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {resources.map((resource) => (
            <ResourceCard key={resource.id} resource={resource} user={user} />
          ))}
        </div>
      )}
    </div>
  );
};
