
import React from 'react';
import { Lock, FileText, Music, Link as LinkIcon, ExternalLink, Download, Clock } from 'lucide-react';
import { Resource, User, ResourceType } from '../types';
import { isResourceLocked } from '../utils';

interface ResourceCardProps {
  resource: Resource;
  user: User;
}

export const ResourceCard: React.FC<ResourceCardProps> = ({ resource, user }) => {
  const { locked: timeLocked, remaining } = isResourceLocked(resource.createdAt, resource.lockDays);
  const manualLocked = resource.isManualLock;
  const isLocked = timeLocked || manualLocked;

  const getIcon = (type: ResourceType) => {
    switch (type) {
      case 'PDF': return <FileText size={14} />;
      case 'Áudio': return <Music size={14} />;
      case 'Link': return <LinkIcon size={14} />;
    }
  };

  const handleAccess = () => {
    if (isLocked) return;

    if (resource.type === 'Link' && resource.externalLink) {
      // Ensure the link has a protocol
      const url = resource.externalLink.startsWith('http') 
        ? resource.externalLink 
        : `https://${resource.externalLink}`;
      window.open(url, '_blank', 'noopener,noreferrer');
    } else if (resource.fileBase64) {
      // Create a temporary link to download/view the base64 file
      const link = document.createElement('a');
      link.href = resource.fileBase64;
      link.download = resource.title;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const getButtonContent = () => {
    if (manualLocked) return <span>EM BREVE</span>;
    if (timeLocked) return <span>CONTEÚDO BLOQUEADO</span>;
    
    switch (resource.type) {
      case 'Link':
        return (
          <>
            <ExternalLink size={14} />
            <span>ACESSAR LINK</span>
          </>
        );
      case 'PDF':
        return (
          <>
            <Download size={14} />
            <span>BAIXAR E-BOOK</span>
          </>
        );
      case 'Áudio':
        return (
          <>
            <Music size={14} />
            <span>OUVIR ÁUDIO</span>
          </>
        );
    }
  };

  return (
    <div className="group relative bg-[#0a0a0a] border border-white/5 rounded-xl overflow-hidden transition-all duration-500 hover:border-gold/30 hover:-translate-y-2 shadow-2xl flex flex-col h-full">
      {/* Cover Image Area */}
      <div className="aspect-[3/4] relative overflow-hidden bg-black flex items-center justify-center">
        <img 
          src={resource.coverBase64} 
          alt={resource.title} 
          className={`w-full h-full object-contain transition-all duration-700 group-hover:scale-105 ${isLocked ? 'grayscale opacity-20' : 'opacity-90 group-hover:opacity-100'}`}
        />

        {/* Locked Overlay */}
        {isLocked && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-10 bg-black/60 backdrop-blur-[2px]">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-4 border transition-colors ${manualLocked ? 'bg-gold/20 border-gold/30' : 'bg-wine/20 border-wine/30'}`}>
              <Lock className={manualLocked ? 'text-gold' : 'text-wine animate-pulse'} size={20} />
            </div>
            
            {manualLocked ? (
              <>
                <h4 className="font-playfair text-2xl font-bold mb-1 italic text-gold tracking-widest">Lock</h4>
                <p className="text-[11px] text-gray-300 font-bold tracking-[0.3em] uppercase bg-black/40 px-4 py-1.5 rounded-full border border-gold/20 backdrop-blur-sm">
                  Em breve
                </p>
              </>
            ) : (
              <>
                <h4 className="font-playfair text-lg font-bold mb-1 italic text-white">Bloqueado</h4>
                <p className="text-[10px] text-gray-400 font-bold tracking-widest uppercase flex items-center justify-center bg-black/40 px-3 py-1 rounded-full border border-white/5">
                  <Clock size={12} className="mr-1 text-gold" /> {remaining}
                </p>
              </>
            )}
          </div>
        )}
        
        {/* Type Badge on Image */}
        <div className="absolute top-4 left-4 z-20">
          <span className="flex items-center space-x-1.5 px-3 py-1.5 bg-black/80 backdrop-blur-md rounded border border-white/10 text-[9px] font-bold tracking-[0.2em] text-gold uppercase">
            {getIcon(resource.type)}
            <span>{resource.type}</span>
          </span>
        </div>
      </div>

      {/* Info and Action Area */}
      <div className="p-6 space-y-4 flex flex-col flex-1 justify-between">
        <div>
          <h3 className="font-playfair text-xl font-bold group-hover:text-gold transition-colors truncate mb-1 leading-tight">
            {resource.title}
          </h3>
          <p className="text-xs text-gray-500 font-medium line-clamp-2 leading-relaxed opacity-80 min-h-[2rem]">
            {resource.description || 'Nenhuma descrição disponível para este recurso premium.'}
          </p>
        </div>

        <button 
          onClick={handleAccess}
          disabled={isLocked}
          className={`w-full py-4 rounded-sm font-montserrat font-bold text-[10px] tracking-[0.3em] flex items-center justify-center space-x-3 transition-all duration-300 shadow-lg ${
            isLocked 
            ? 'bg-white/5 text-gray-600 cursor-not-allowed border border-white/5 opacity-50' 
            : 'bg-gold text-matte hover:bg-white hover:text-black hover:shadow-gold/20 active:scale-[0.98]'
          }`}
        >
          {getButtonContent()}
        </button>
      </div>
    </div>
  );
};
