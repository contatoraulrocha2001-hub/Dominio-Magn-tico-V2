
import React from 'react';
import { User } from '../types';
import { ShieldCheck, Trophy, Zap, Clock } from 'lucide-react';

interface ProfileViewProps {
  user: User;
  setUser: (u: User) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ user }) => {
  const stats = [
    { label: 'STATUS', value: 'MEMBRO ELITE', icon: ShieldCheck },
    { label: 'CONTEÚDOS', value: '12 ACESSADOS', icon: Trophy },
    { label: 'DESDE', value: new Date(user.joinedAt).toLocaleDateString(), icon: Clock },
  ];

  return (
    <div className="space-y-16 max-w-4xl">
      <header>
        <h3 className="font-playfair text-white/40 text-sm tracking-widest uppercase mb-2">Seu Domínio</h3>
        <h2 className="font-playfair text-6xl font-bold leading-tight">
          Perfil de <br />
          <span className="italic text-gold">{user.name}</span>
        </h2>
      </header>

      <div className="grid grid-cols-3 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="glass p-6 rounded-xl border border-white/5">
            <stat.icon className="text-gold mb-4" size={24} strokeWidth={1.5} />
            <p className="text-[10px] text-gray-500 font-bold tracking-widest uppercase mb-1">{stat.label}</p>
            <p className="font-playfair text-xl font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="glass p-10 rounded-2xl border border-white/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Zap size={120} className="text-gold" />
        </div>
        
        <div className="relative z-10">
          <div className="flex justify-between items-end mb-6">
            <div>
              <h3 className="font-playfair text-2xl font-bold italic mb-2">Potência Magnética™</h3>
              <p className="text-sm text-gray-400 max-w-md">Seu nível de influência e autoridade dentro da plataforma baseada no consumo de conteúdo.</p>
            </div>
            <div className="text-right">
              <span className="font-playfair text-5xl font-bold text-gold">{user.magneticPower}%</span>
            </div>
          </div>

          <div className="w-full h-4 bg-white/5 rounded-full overflow-hidden border border-white/5 p-0.5">
            <div 
              className="h-full bg-gradient-to-r from-gold via-white to-gold rounded-full shadow-[0_0_20px_rgba(198,166,100,0.3)]" 
              style={{ width: `${user.magneticPower}%` }}
            />
          </div>
          
          <div className="mt-8 flex items-center justify-between text-[10px] font-bold tracking-[0.2em] text-gray-600 uppercase">
            <span>Iniciante</span>
            <span>Mestre Magnético</span>
            <span>Domínio Supremo</span>
          </div>
        </div>
      </div>

      <div className="pt-8 border-t border-white/5 flex space-x-4">
        <button className="bg-white/5 hover:bg-white/10 text-white px-8 py-3 rounded-sm font-montserrat font-bold text-[10px] tracking-widest uppercase transition-all">
          Editar Dados
        </button>
        <button className="bg-wine/20 hover:bg-wine text-white px-8 py-3 rounded-sm font-montserrat font-bold text-[10px] tracking-widest uppercase transition-all">
          Mudar Senha
        </button>
      </div>
    </div>
  );
};
