
import React, { useState } from 'react';
import { User } from '../types';
import { User as UserIcon, Lock, ArrowRight } from 'lucide-react';

interface LoginViewProps {
  onLogin: (user: User) => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Logic: If admin credentials are used, grant admin role. Otherwise, grant member role.
    if (email === 'admin@dominio.com' && password === 'admin123') {
      onLogin({
        id: 'admin-1',
        name: 'Comandante Supremo',
        role: 'admin',
        joinedAt: Date.now(),
        magneticPower: 100
      });
    } else if (email && password) {
      // Basic member login for any other valid-looking credentials
      onLogin({
        id: 'user-' + Date.now(),
        name: 'Membro Elite',
        role: 'user',
        joinedAt: Date.now(),
        magneticPower: 45
      });
    } else {
      setError('Credenciais inválidas ou campos vazios.');
    }
  };

  return (
    <div className="min-h-screen bg-matte flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background Decor - Dark Blobs as seen in screenshot */}
      <div className="absolute top-[-15%] left-[-10%] w-[50%] h-[50%] bg-white/5 blur-[150px] rounded-full pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[55%] h-[55%] bg-wine/10 blur-[150px] rounded-full pointer-events-none" />
      
      <div className="w-full max-w-md z-10 animate-in fade-in slide-in-from-bottom-6 duration-1000">
        <div className="text-center mb-10">
          <h1 className="font-playfair text-5xl font-bold tracking-tighter mb-3">
            DOMÍNIO <span className="text-gold italic">MAGNÉTICO</span>
            <span className="text-[14px] align-top ml-1 opacity-40">TM</span>
          </h1>
          <p className="font-montserrat text-[11px] font-bold tracking-[0.4em] text-gray-500 uppercase">
            Curadoria de Conteúdo Premium
          </p>
        </div>

        <div className="bg-[#0a0a0a] rounded-2xl overflow-hidden border border-white/5 shadow-[0_25px_50px_-12px_rgba(0,0,0,0.8)]">
          {/* Header area replaced with simple label per user request */}
          <div className="p-10 pb-4 text-center">
            <h2 className="text-gray-300 font-montserrat text-[10px] font-bold tracking-[0.3em] uppercase opacity-60">
              Acesso Restrito
            </h2>
          </div>

          <form onSubmit={handleLogin} className="p-10 pt-4 space-y-7">
            {error && (
              <div className="bg-wine/10 border border-wine/20 p-4 rounded text-[10px] font-bold text-wine tracking-widest uppercase text-center">
                {error}
              </div>
            )}
            
            <div className="space-y-5">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-gray-500 mb-3 font-montserrat opacity-80">
                  Identificação
                </label>
                <div className="relative group">
                  <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-black/60 border border-white/10 rounded-lg p-5 text-sm focus:border-wine/50 outline-none transition-all pl-14 font-montserrat text-white"
                    placeholder="" 
                    required
                  />
                  <UserIcon className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-600 group-focus-within:text-wine transition-colors" size={20} />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-gray-500 mb-3 font-montserrat opacity-80">
                  Chave de Acesso
                </label>
                <div className="relative group">
                  <input 
                    type="password" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-black/60 border border-white/10 rounded-lg p-5 text-sm focus:border-wine/50 outline-none transition-all pl-14 font-montserrat text-white"
                    placeholder=""
                    required
                  />
                  <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-600 group-focus-within:text-wine transition-colors" size={20} />
                </div>
              </div>
            </div>

            <button 
              type="submit"
              className="w-full bg-wine hover:bg-wine/90 text-white py-5 rounded-lg font-montserrat font-bold text-[11px] tracking-[0.3em] uppercase transition-all flex items-center justify-center space-x-4 group shadow-2xl shadow-wine/20"
            >
              <span>Entrar no Domínio</span>
              <ArrowRight size={18} className="group-hover:translate-x-1.5 transition-transform" />
            </button>
          </form>
        </div>

        <div className="mt-12 text-center opacity-40">
          <p className="text-gray-500 text-[10px] font-bold tracking-[0.2em] uppercase">
            © 2024 Domínio Magnético • Todos os Direitos Reservados
          </p>
        </div>
      </div>
    </div>
  );
};
