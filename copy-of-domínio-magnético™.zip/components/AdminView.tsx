
import React, { useState } from 'react';
import { Plus, Trash2, Edit3, GripVertical, FileText, Music, Link as LinkIcon, X } from 'lucide-react';
import { Resource, ResourceType } from '../types';
import { ResourceForm } from './ResourceForm';

interface AdminViewProps {
  resources: Resource[];
  onAdd: (r: Resource) => void;
  onDelete: (id: string) => void;
  onUpdate: (r: Resource) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({ resources, onAdd, onDelete, onUpdate }) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingResource, setEditingResource] = useState<Resource | null>(null);

  const getIconForType = (type: ResourceType) => {
    switch (type) {
      case 'PDF': return <FileText size={18} />;
      case 'Áudio': return <Music size={18} />;
      case 'Link': return <LinkIcon size={18} />;
    }
  };

  const handleEdit = (r: Resource) => {
    setEditingResource(r);
    setIsFormOpen(true);
  };

  return (
    <div className="space-y-12">
      <header className="flex justify-between items-end border-b border-white/10 pb-8">
        <div>
          <h3 className="font-playfair text-white/40 text-sm tracking-widest uppercase mb-2">Painel de Gestão</h3>
          <h2 className="font-playfair text-5xl font-bold">
            Arsenal do <span className="italic text-gold">Admin</span>
          </h2>
        </div>
        <button 
          onClick={() => { setEditingResource(null); setIsFormOpen(true); }}
          className="bg-gold hover:bg-gold/90 text-matte px-6 py-3 rounded-sm font-montserrat font-bold text-xs tracking-widest flex items-center space-x-2 transition-all shadow-xl shadow-gold/10"
        >
          <Plus size={16} />
          <span>NOVO RECURSO</span>
        </button>
      </header>

      <div className="space-y-4">
        {resources.length === 0 ? (
          <div className="py-20 text-center border-2 border-dashed border-white/5 rounded-lg">
            <p className="text-gray-500 font-montserrat italic">Nenhum recurso cadastrado no arsenal.</p>
          </div>
        ) : (
          resources.map((resource) => (
            <div 
              key={resource.id} 
              className="bg-sidebar/50 border border-white/5 p-4 rounded-lg flex items-center justify-between group hover:border-gold/30 transition-all"
            >
              <div className="flex items-center space-x-6">
                <div className="text-gray-700">
                  <GripVertical size={20} />
                </div>
                <div className="w-16 h-20 bg-matte rounded overflow-hidden flex-shrink-0 border border-white/5 shadow-lg">
                  <img src={resource.coverBase64} alt="" className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                </div>
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-gold">{getIconForType(resource.type)}</span>
                    <h4 className="font-montserrat font-bold text-sm tracking-wide">{resource.title}</h4>
                  </div>
                  <p className="text-xs text-gray-500 line-clamp-1 max-w-md">{resource.description}</p>
                </div>
              </div>

              <div className="flex items-center space-x-8">
                <div className="text-right">
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Bloqueio</p>
                  <p className="text-sm font-playfair italic text-gold">{resource.lockDays} dias</p>
                </div>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleEdit(resource)}
                    className="p-3 text-gray-400 hover:text-white hover:bg-white/5 rounded-full transition-all"
                  >
                    <Edit3 size={18} />
                  </button>
                  <button 
                    onClick={() => onDelete(resource.id)}
                    className="p-3 text-gray-400 hover:text-wine hover:bg-wine/10 rounded-full transition-all"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {isFormOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-matte/90 backdrop-blur-md">
          <div className="w-full max-w-2xl bg-sidebar border border-white/10 rounded-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
            <div className="p-6 border-b border-white/5 flex justify-between items-center">
              <h3 className="font-playfair text-xl font-bold">
                {editingResource ? 'Editar Recurso' : 'Configurar Novo Recurso'}
              </h3>
              <button onClick={() => setIsFormOpen(false)} className="text-gray-500 hover:text-white transition-colors">
                <X size={24} />
              </button>
            </div>
            <div className="p-8">
              <ResourceForm 
                onSave={(r) => {
                  editingResource ? onUpdate(r) : onAdd(r);
                  setIsFormOpen(false);
                }}
                initialData={editingResource}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
