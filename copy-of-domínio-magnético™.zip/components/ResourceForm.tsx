
import React, { useState, useEffect } from 'react';
import { Resource, ResourceType } from '../types';
import { fileToBase64 } from '../utils';
import { Upload, Link as LinkIcon, ChevronDown, Lock } from 'lucide-react';

interface ResourceFormProps {
  onSave: (r: Resource) => void;
  initialData: Resource | null;
}

export const ResourceForm: React.FC<ResourceFormProps> = ({ onSave, initialData }) => {
  const [title, setTitle] = useState(initialData?.title || '');
  const [description, setDescription] = useState(initialData?.description || '');
  const [type, setType] = useState<ResourceType>(initialData?.type || 'PDF');
  const [lockDays, setLockDays] = useState(initialData?.lockDays || 0);
  const [isManualLock, setIsManualLock] = useState(initialData?.isManualLock || false);
  const [externalLink, setExternalLink] = useState(initialData?.externalLink || '');
  const [cover, setCover] = useState<string>(initialData?.coverBase64 || '');
  const [fileData, setFileData] = useState<string>(initialData?.fileBase64 || '');
  const [isProcessing, setIsProcessing] = useState(false);

  // Mutually exclusive logic
  const handleLockDaysChange = (val: number) => {
    setLockDays(val);
    if (val > 0) {
      setIsManualLock(false);
    }
  };

  const handleManualLockToggle = () => {
    const newState = !isManualLock;
    setIsManualLock(newState);
    if (newState) {
      setLockDays(0);
    }
  };

  const handleCoverChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsProcessing(true);
      try {
        const base64 = await fileToBase64(e.target.files[0]);
        setCover(base64);
      } catch (err) {
        console.error(err);
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsProcessing(true);
      try {
        const base64 = await fileToBase64(e.target.files[0]);
        setFileData(base64);
      } catch (err) {
        console.error(err);
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !cover) {
      alert('Título e Capa são obrigatórios');
      return;
    }
    if (type === 'Link' && !externalLink) {
      alert('Por favor, insira o link do recurso');
      return;
    }

    onSave({
      id: initialData?.id || Date.now().toString(),
      title,
      description,
      type,
      lockDays,
      isManualLock,
      coverBase64: cover,
      fileBase64: type !== 'Link' ? fileData : undefined,
      externalLink: type === 'Link' ? externalLink : undefined,
      createdAt: initialData?.createdAt || Date.now()
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left Column */}
        <div className="space-y-5">
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2 font-montserrat">Título do Método</label>
            <input 
              type="text" 
              value={title} 
              onChange={e => setTitle(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded p-4 text-sm focus:border-gold outline-none transition-all placeholder:text-gray-700 font-montserrat"
              placeholder="Ex: Domínio Magnético 2.0"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2 font-montserrat">Descrição Curta</label>
            <textarea 
              value={description} 
              onChange={e => setDescription(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded p-4 text-sm focus:border-gold outline-none transition-all h-32 resize-none placeholder:text-gray-700 font-montserrat"
              placeholder="Descreva o impacto deste recurso..."
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="relative">
              <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2 font-montserrat">Tipo de Recurso</label>
              <div className="relative">
                <select 
                  value={type} 
                  onChange={e => setType(e.target.value as ResourceType)}
                  className="w-full bg-black/40 border border-white/10 rounded p-4 text-sm focus:border-gold outline-none transition-all appearance-none cursor-pointer font-montserrat pr-10"
                >
                  <option value="PDF">PDF (E-book)</option>
                  <option value="Áudio">Áudio (MP3)</option>
                  <option value="Link">Link Externo</option>
                </select>
                <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500" />
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2 font-montserrat">Dias de Lock</label>
                <input 
                  type="number" 
                  value={lockDays} 
                  disabled={isManualLock}
                  onChange={e => handleLockDaysChange(parseInt(e.target.value) || 0)}
                  className={`w-full bg-black/40 border border-white/10 rounded p-4 text-sm focus:border-gold outline-none transition-all font-montserrat ${isManualLock ? 'opacity-30 cursor-not-allowed' : ''}`}
                  min="0"
                />
              </div>
              
              <div className="pt-2">
                <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-3 font-montserrat">Status de Entrega</label>
                <button
                  type="button"
                  disabled={lockDays > 0}
                  onClick={handleManualLockToggle}
                  className={`w-full flex items-center justify-between p-4 rounded border transition-all duration-300 ${
                    isManualLock 
                      ? 'bg-wine/10 border-wine text-wine' 
                      : (lockDays > 0 ? 'opacity-30 cursor-not-allowed border-white/5 text-gray-600' : 'bg-black/40 border-white/10 text-gray-500')
                  }`}
                >
                  <span className="text-[10px] font-bold uppercase tracking-widest">Conteúdo Bloqueado</span>
                  <Lock size={14} className={isManualLock ? 'animate-pulse' : ''} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-5">
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2 font-montserrat">Capa do Método (PNG/JPG)</label>
            <div className="relative group overflow-hidden rounded-lg">
              <input 
                type="file" 
                accept="image/*" 
                onChange={handleCoverChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              />
              <div className={`h-44 border-2 border-dashed border-white/10 rounded-lg flex flex-col items-center justify-center transition-all duration-300 ${cover ? 'bg-black' : 'group-hover:border-gold/50 bg-white/5'}`}>
                {cover ? (
                  <img src={cover} alt="Preview" className="h-full w-full object-contain p-2" />
                ) : (
                  <>
                    <Upload className="text-gray-600 mb-3 group-hover:text-gold transition-colors" size={36} />
                    <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest group-hover:text-gold/80 transition-colors">Upload Capa</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2 font-montserrat">
              {type === 'Link' ? 'Endereço do Link (Barra)' : 'Arquivo do Método (Max 5MB)'}
            </label>
            {type === 'Link' ? (
              <div className="flex items-center bg-black/60 border border-gold/30 rounded p-4 shadow-lg shadow-gold/5 group focus-within:border-gold transition-all animate-in fade-in slide-in-from-top-2 duration-300">
                <LinkIcon size={18} className="text-gold mr-4 flex-shrink-0" />
                <input 
                  type="url" 
                  value={externalLink} 
                  onChange={e => setExternalLink(e.target.value)}
                  className="flex-1 bg-transparent text-sm outline-none font-montserrat placeholder:text-gray-700 text-white"
                  placeholder="Cole o link aqui (https://...)"
                  autoFocus
                />
              </div>
            ) : (
              <div className="relative group">
                <input 
                  type="file" 
                  onChange={handleFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
                <div className={`p-4 border rounded flex items-center justify-center space-x-4 transition-all duration-300 ${fileData ? 'bg-gold/10 border-gold text-gold shadow-lg shadow-gold/5' : 'bg-white/5 border-white/10 text-gray-500 group-hover:border-white/20'}`}>
                  <Upload size={20} className={fileData ? 'text-gold' : 'text-gray-500'} />
                  <span className={`text-xs font-bold uppercase tracking-[0.15em] ${fileData ? 'text-gold' : 'text-gray-500'}`}>
                    {fileData ? 'Arquivo Selecionado' : 'Selecionar Mídia'}
                  </span>
                </div>
              </div>
            )}
            {type !== 'Link' && (
               <p className="text-[9px] text-gray-600 mt-2 font-bold tracking-widest uppercase">Formatos sugeridos: .pdf, .mp3</p>
            )}
          </div>
        </div>
      </div>

      <div className="pt-8 border-t border-white/5 flex justify-end">
        <button 
          type="submit" 
          disabled={isProcessing}
          className="bg-gold text-matte px-12 py-5 font-montserrat font-bold text-xs tracking-[0.25em] rounded-sm hover:bg-white hover:text-black hover:scale-105 active:scale-95 transition-all duration-300 disabled:opacity-50 shadow-2xl shadow-gold/20"
        >
          {isProcessing ? 'PROCESSANDO...' : (initialData ? 'SALVAR ALTERAÇÕES' : 'CONFIRMAR CADASTRO')}
        </button>
      </div>
    </form>
  );
};
